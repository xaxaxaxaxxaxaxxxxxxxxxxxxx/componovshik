#include "iterator.h"

Iterator::Iterator()
{

}

