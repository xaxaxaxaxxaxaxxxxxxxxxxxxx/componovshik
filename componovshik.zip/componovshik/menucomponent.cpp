#include "menucomponent.h"

void MenuComponent::add(MenuComponent *menuComponent) {
	throw new UnsupportedOperationException();
}

void MenuComponent::remove(MenuComponent* menuComponent) {
	throw new UnsupportedOperationException();
}

MenuComponent* MenuComponent::getChild(int i) {
	throw new UnsupportedOperationException();
}

std::string MenuComponent::getName() {
	throw new UnsupportedOperationException();
}

std::string MenuComponent::getDescription() {
	throw new UnsupportedOperationException();
}

double MenuComponent::getPrice() {
	throw new UnsupportedOperationException();
}

bool MenuComponent::isVegeterian() {
	throw new UnsupportedOperationException();
}

void MenuComponent::print() {
	throw new UnsupportedOperationException();
}
